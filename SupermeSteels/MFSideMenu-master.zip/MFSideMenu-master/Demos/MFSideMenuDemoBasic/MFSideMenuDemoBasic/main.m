//
//  main.m
//  MFSideMenuDemo
//
//  Created by Michael Frederick on 3/19/12.
//  Copyright (c) 2012 University of Wisconsin - Madison. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MFAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MFAppDelegate class]));
    }
}
