//
//  MFAppDelegate.h
//  MFSideMenuDemoUITabBarController
//
//  Created by Michael Frederick on 3/19/13.
//  Copyright (c) 2013 Michael Frederick. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MFAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
